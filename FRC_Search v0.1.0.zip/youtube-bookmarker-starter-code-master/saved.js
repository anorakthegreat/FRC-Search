let name = "d"
let year = "d"

function setYear(yr){
    year = yr
}

function getYear(){
    return year
}


function setName(nm){
    nane = nm
}

function getName(){
    return name
}