class TeamData {
    constructor(text1, href1) {
      this.text = text1
      this.href = href1
    }
  
    getText(){
        return this.text
    }

    getHref(){
        return this.href
    }
  }
  